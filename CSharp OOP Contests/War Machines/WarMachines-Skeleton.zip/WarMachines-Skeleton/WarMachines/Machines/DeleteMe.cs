﻿namespace WarMachines.Machines
{
    public class DeleteMe
    {
        // TODO: Implement all machine classes in this namespace - WarMachines.Machines
    }
}
